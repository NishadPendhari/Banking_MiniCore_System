package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Customer {
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private Long CustomerId;
  private String name;
  private String email;
  private String phnno;
  
  public Customer() {
	  
  }
  
  public Long getCustomerId() {
	return CustomerId;
  }
  public void setCustomerId(Long customerId) {
	CustomerId = customerId;
  }
  public String getName() {
	return name;
  }
  public void setName(String name) {
	this.name = name;
  }
  public String getEmail() {
	return email;
  }
  public void setEmail(String email) {
	this.email = email;
  }
  public String getPhnno() {
	return phnno;
  }
  public void setPhnno(String phnno) {
	this.phnno = phnno;
  }
  
}
