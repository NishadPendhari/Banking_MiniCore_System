package com.example.demo.Exception;

public class InsufficientBalanceException extends RuntimeException {
     public InsufficientBalanceException(String message)
     {
    	 super(message);
     }
}
