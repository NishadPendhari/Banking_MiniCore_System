package com.example.demo.Controller;


import com.example.demo.Entity.auditLog;
import com.example.demo.Repository.AuditLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/audit")
public class auditController {

    @Autowired
    private AuditLogRepository repository;

    @GetMapping
    public List<auditLog> getAllLogs() {
        return repository.findAll();
    }
}
