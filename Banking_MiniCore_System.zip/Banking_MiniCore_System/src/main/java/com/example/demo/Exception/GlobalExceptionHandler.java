package com.example.demo.Exception;



import com.example.demo.dto.apiResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<apiResponse> handleNotFound(
            ResourceNotFoundException ex) {

        apiResponse response =
                new apiResponse(
                        ex.getMessage(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                response,
                HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(InsufficientBalanceException.class)
    public ResponseEntity<apiResponse> handleBalance(
            InsufficientBalanceException ex) {

        apiResponse response =
                new apiResponse(
                        ex.getMessage(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                response,
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<apiResponse> handleException(
            Exception ex) {

        apiResponse response =
                new apiResponse(
                        ex.getMessage(),
                        LocalDateTime.now());

        return new ResponseEntity<>(
                response,
                HttpStatus.INTERNAL_SERVER_ERROR);
    }
}