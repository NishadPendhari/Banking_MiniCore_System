package com.example.demo.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Account;
import com.example.demo.Service.AccountService;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @Autowired
    private AccountService service;

    @PostMapping("/{customerId}")
    public Account createAccount(@RequestBody Account account, @PathVariable Long customerId) {

        return service.createAccount(account, customerId);
    }

    @GetMapping("/{id}")
    public Account getAccount(@PathVariable Long id) {

        return service.getAccount(id);
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam Long accountId,@RequestParam Double amount) {

        return service.deposit(accountId, amount);
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam Long accountId, @RequestParam Double amount) {

        return service.withdraw(accountId, amount);
    }

    @PostMapping("/transfer")
    public String transfer(@RequestParam Long fromId,@RequestParam Long toId,@RequestParam Double amount)
    {

        return service.transfer(fromId,toId,amount);
    }

    @DeleteMapping("/{id}")
    public String deleteAccount(@PathVariable Long id)
    {
         service.deleteAccount(id);
         return "Account Deleted Successfully";
    }
}