package com.example.demo.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Account;
import com.example.demo.Entity.TransactionRecord;
import com.example.demo.Repository.TransactionRepository;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository repository;

    public void saveTransaction(Account account,String type,Double amount)
    {

        TransactionRecord transaction =new TransactionRecord();

        transaction.setAccount(account);
        transaction.setTransactionType(type);
        transaction.setAmount(amount);
        transaction.setTransactionDate(LocalDateTime.now());

        repository.save(transaction);
    }

    public List<TransactionRecord> getTransactions(Long accountId) {
        return repository.findByAccountAccountId(accountId);
    }
}
