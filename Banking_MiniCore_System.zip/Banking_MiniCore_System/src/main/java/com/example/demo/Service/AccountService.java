package com.example.demo.Service;

import com.example.demo.Repository.CustomerRepository;
import com.example.demo.Entity.Account;
import com.example.demo.Entity.Customer;
import com.example.demo.Exception.InsufficientBalanceException;
import com.example.demo.Exception.ResourceNotFoundException;
import com.example.demo.Repository.AccountRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountService {

    private static final Logger logger =
            LoggerFactory.getLogger(AccountService.class);

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private CustomerRepository CustomerRepository;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private AuditService auditService;

    public Account createAccount(Account account,
                                 Long customerId) {

        Customer customer =CustomerRepository.findById(customerId).orElseThrow(() -> new ResourceNotFoundException("Customer Not Found"));

        account.setCustomer(customer);

        Account saved =accountRepository.save(account);

        auditService.saveLog("ACCOUNT CREATED","ADMIN");

        return saved;
    }

    public Account getAccount(Long id) {

        return accountRepository.findById(id).orElseThrow(() ->new ResourceNotFoundException("Account Not Found"));
    }

    @Transactional
    public String deposit(Long accountId,Double amount) {

        logger.info("Deposit Started");

        Account account = getAccount(accountId);

        account.setBalance(account.getBalance() + amount);

        accountRepository.save(account);

        transactionService.saveTransaction(account,"DEPOSIT",amount);

        auditService.saveLog("DEPOSIT","ADMIN");

        logger.info("Deposit Successful");

        return "Deposit Successful";
    }

    @Transactional
    public String withdraw(Long accountId,Double amount) {

        logger.info("Withdraw Started");

        Account account = getAccount(accountId);

        if(account.getBalance() < amount) {

            logger.error("Insufficient Balance");

            throw new InsufficientBalanceException("Insufficient Balance");
        }

        account.setBalance(account.getBalance() - amount);

        accountRepository.save(account);

        transactionService.saveTransaction(account,"WITHDRAW",amount);

        auditService.saveLog( "WITHDRAW","ADMIN");

        logger.info("Withdraw Successful");

        return "Withdraw Successful";
    }

    @Transactional
    public String transfer(Long fromId,
                           Long toId,
                           Double amount) {

        logger.info("Transfer Started");

        Account sender = getAccount(fromId);

        Account receiver = getAccount(toId);

        if(sender.getBalance() < amount) {

            logger.error("Insufficient Balance");

            throw new InsufficientBalanceException( "Insufficient Balance");
        }

        sender.setBalance(sender.getBalance() - amount);

        receiver.setBalance(receiver.getBalance() + amount);

        accountRepository.save(sender);
        accountRepository.save(receiver);

        transactionService.saveTransaction(sender,"TRANSFER SENT", amount);

        transactionService.saveTransaction(receiver,"TRANSFER RECEIVED",amount);

        auditService.saveLog("TRANSFER", "ADMIN");

        logger.info("Transfer Successful");

        return "Transfer Successful";
    }

    public void deleteAccount(Long id) {

        Account account = getAccount(id);

        accountRepository.delete(account);
    }
}