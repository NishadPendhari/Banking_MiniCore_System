package com.example.demo.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.TransactionRecord;
import com.example.demo.Service.TransactionService;

import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService service;

    @GetMapping("/{accountId}")
    public List<TransactionRecord> getTransactions (@PathVariable Long accountId) {

        return service.getTransactions(accountId);
    }
}