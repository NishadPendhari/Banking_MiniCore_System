package com.example.demo.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Service.AccountService;
import com.example.demo.Entity.Account;

@RestController
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private AccountService accountService;

    @GetMapping("/balance/{id}")
    public Double getBalance(@PathVariable Long id) {

        Account account =accountService.getAccount(id);

        return account.getBalance();
    }
}