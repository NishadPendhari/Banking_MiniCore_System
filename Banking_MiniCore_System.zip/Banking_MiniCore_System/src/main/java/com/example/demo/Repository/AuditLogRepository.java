package com.example.demo.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.auditLog;

public interface AuditLogRepository extends JpaRepository<auditLog,Long> {



}
