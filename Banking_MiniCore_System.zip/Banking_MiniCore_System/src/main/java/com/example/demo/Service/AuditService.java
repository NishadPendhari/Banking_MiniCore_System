package com.example.demo.Service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.auditLog;
import com.example.demo.Repository.AuditLogRepository;

@Service
public class AuditService {
	@Autowired
      private AuditLogRepository repository;
      
      public void saveLog(String action,String user)
      {
    	  auditLog log=new auditLog();
    	  
    	  log.setAction(action);
    	  log.setPerformedBy(user);
    	  log.setActionTime(LocalDateTime.now());
    	 System.out.println("User="+ user);
    	  repository.save(log);
      }
}
