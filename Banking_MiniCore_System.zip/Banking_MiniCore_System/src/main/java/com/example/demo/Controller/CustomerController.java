package com.example.demo.Controller;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Customer;
import com.example.demo.Service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService service;

    @PostMapping
    public Customer addCustomer(@RequestBody Customer customer) {

        return service.save(customer);
    }

    @GetMapping
    public Page<Customer> getAllCustomers( @RequestParam(defaultValue = "0") int page,@RequestParam(defaultValue = "5") int size)
    {

     return service.getAll(page, size);
    }

    @GetMapping("/{id}")
    public Customer getCustomer( @PathVariable Long id) {

        return service.getById(id);
    }

    @PutMapping("/{id}")
    public Customer updateCustomer(@PathVariable Long id,@RequestBody Customer customer) {

        return service.update(id, customer);
    }

    @DeleteMapping("/{id}")
    public String deleteCustomer(@PathVariable Long id) 
    {

        service.delete(id);
        return "Customer Deleted Successfully";
    }
}