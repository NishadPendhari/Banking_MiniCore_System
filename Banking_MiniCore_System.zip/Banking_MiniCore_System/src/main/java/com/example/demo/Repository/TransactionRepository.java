package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.TransactionRecord;

public interface TransactionRepository extends JpaRepository<TransactionRecord,Long> {
    List<TransactionRecord>findByAccountAccountId(Long accId);
}
