package com.example.demo.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Customer;
import com.example.demo.Exception.ResourceNotFoundException;
import com.example.demo.Repository.CustomerRepository;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository repository;

    public Customer save(Customer customer) {
        return repository.save(customer);
    }

    public Page<Customer> getAll(int page,int size) {
        return repository.findAll(PageRequest.of(page,size));
    }

    public Customer getById(Long id) {

        return repository.findById(id).orElseThrow(() ->new ResourceNotFoundException( "Customer Not Found"));
    }

    public Customer update(Long id,
                           Customer customer) {

        Customer existing = getById(id);

        existing.setName(customer.getName());
        existing.setEmail(customer.getEmail());
        existing.setPhnno(customer.getPhnno());

        return repository.save(existing);
    }

    public void delete(Long id) {

        Customer customer = getById(id);

        repository.delete(customer);
    }
}